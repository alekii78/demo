<?php
for ($count = 1; $count <= 10; $count = $count + 3) {
  echo $count . ' ';
}

?>