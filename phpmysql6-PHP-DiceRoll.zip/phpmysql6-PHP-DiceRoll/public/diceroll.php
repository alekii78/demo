<?php

$roll = rand(1, 6);

echo 'You rolled a ' . $roll;


if ($roll == 6) {
  echo 'You win!';
}

?>