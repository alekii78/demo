<h2>Registration Successful</h2>

<p>You are now registered on the Internet Joke Database</p>