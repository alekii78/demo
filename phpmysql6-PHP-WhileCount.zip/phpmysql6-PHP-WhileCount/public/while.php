<?php
$count = 1;
while ($count <= 10) {
  echo $count . ' ';
  ++$count;
}
?>