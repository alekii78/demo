<!doctype html>
<html>
	<head>
		<title>Enter your name</title>
		<link rel="stylesheet" href="form.css" />
		<meta charset="utf-8">	
	</head>
	<body>
	<form action="" method="post">
	  	<label for="firstname">First name:</label>
	    <input type="text" name="firstname" id="firstname">
	  	
	  	<label for="lastname">Last name:</label>
	    <input type="text" name="lastname" id="lastname">

	 	<input type="submit" value="GO">
	</form>

</body>