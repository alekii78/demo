<form action="" method="post">
    <label for="email">Your email address</label>
    <input name="author[email]" id="email" type="text">
    
    <label for="name">Your name</label>
    <input name="author[name]" id="name" type="text">

    <label for="password">Password</label>
    <input name="author[password]" id="password" type="password">
 
    <input type="submit" name="submit" value="Register account">
</form>