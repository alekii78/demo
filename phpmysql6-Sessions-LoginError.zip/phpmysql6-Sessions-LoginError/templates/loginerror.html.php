<h2>You are not logged in</h2>

	<p>You must be logged in to view this page. <a href="/login">Click here to log in</a> or <a href="/author/register">Click here to register an account</a></p>