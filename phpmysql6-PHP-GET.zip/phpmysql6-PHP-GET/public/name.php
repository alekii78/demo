<?php
$name = $_GET['name'];
echo 'Welcome to our website, ' . $name . '!';
?>